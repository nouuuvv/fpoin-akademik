import axios from "axios";
import { getToken } from "../lib/getToken";

const api = axios.create({
  baseURL: "http://localhost:5000/api",
  withCredentials: true, // ✅ penting biar cookie terkirim!
});

// masih oke biarin, backend nerima Authorization juga
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;

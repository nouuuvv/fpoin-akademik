"use client";
import React, { useState, useEffect } from "react";

export default function ModalEditMhs({ isOpen, onClose, student, onSubmit }) {
  const [form, setForm] = useState({
    nim: "",
    nama_mhs: "",
    prodi: "S1",
    angkatan: "",
    total_poin: 0,
    id_jur: "",
    tgl_lahir: "",
    pekerjaan: "",
    alamat: "",
    asal_sekolah: "",
    thn_lulus: "",
    tlp_saya: "",
    tlp_rumah: "",
    email: "",
    status: "",
    foto: null,
  });

  // Set data dari student saat modal dibuka
  useEffect(() => {
    if (student) {
      setForm({
        nim: student.nim,
        nama_mhs: student.nama_mhs,
        prodi: student.prodi,
        total_poin: student.poin || 0,
        angkatan: student.angkatan || "",
        id_jur: student.id_jur || "",
        tgl_lahir: student.tgl_lahir || "",
        pekerjaan: student.pekerjaan || "",
        alamat: student.alamat || "",
        asal_sekolah: student.asal_sekolah || "",
        thn_lulus: student.thn_lulus || "",
        tlp_saya: student.tlp_saya || "",
        tlp_rumah: student.tlp_rumah || "",
        email: student.email || "",
        status: student.status || "",
        foto: null,
      });
    }
  }, [student]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-3 sm:px-0">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-sm">
        {/* Header */}
        <div className="flex justify-between items-center px-4 py-2 border-b">
          <h2 className="text-base font-medium text-gray-800 flex items-center">
            <i className="fas fa-edit mr-1.5 text-amber-600 text-sm"></i>
            Edit Mahasiswa
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition text-sm"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="px-4 py-3 space-y-3">
          {/* NIM */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              NIM
            </label>
            <input
              type="text"
              name="nim"
              value={form.nim}
              readOnly
              disabled
              className="w-full px-2.5 py-1.5 border rounded-md shadow-sm bg-gray-100 text-black cursor-not-allowed text-xs"
            />
          </div>

          {/* Nama */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Nama
            </label>
            <input
              type="text"
              name="name"
              value={form.name}
              readOnly
              disabled
              className="w-full px-2.5 py-1.5 border rounded-md shadow-sm bg-gray-100 text-black cursor-not-allowed text-xs"
            />
          </div>

          {/* Prodi */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Prodi
            </label>
            <input
              type="text"
              name="prodi"
              value={form.prodi}
              readOnly
              disabled
              className="w-full px-2.5 py-1.5 border rounded-md shadow-sm bg-gray-100 text-black cursor-not-allowed text-xs"
            />
          </div>

          {/* Poin */}
          <div>
            <label className="block text-xs font-medium text-gray-700 mb-1">
              Total Poin
            </label>
            <input
              type="number"
              name="poin"
              value={form.poin}
              onChange={handleChange}
              min="0"
              className="w-full px-2.5 py-1.5 border rounded-md shadow-sm bg-white text-black focus:ring-1 focus:ring-blue-500 focus:outline-none text-xs"
            />
          </div>

          {/* Tombol */}
          <div className="flex justify-end gap-1.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-md text-gray-600 hover:bg-gray-100 text-xs transition-colors shadow-sm w-full sm:w-auto"
            >
              <i className="fas fa-times mr-1.5"></i>Batal
            </button>

            <button
              type="submit"
              className="px-3 py-1.5 rounded-md bg-amber-600 text-white hover:bg-amber-700 text-xs transition-colors shadow-sm w-full sm:w-auto"
            >
              <i className="fas fa-save mr-1.5"></i>Simpan
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

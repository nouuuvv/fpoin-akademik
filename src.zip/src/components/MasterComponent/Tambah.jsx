"use client";
import React, { useState } from "react";
import { createPortal } from "react-dom";

export default function ModalTambahPoin({ isOpen, onClose, onSave }) {
  const [form, setForm] = useState({
    kode: "",
    jenis: "",
    posisi: "",
    poin: 0,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: name === "kode" ? value.toUpperCase() : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!/^[A-Z0-9]{4,}$/.test(form.kode)) {
      alert("Kode harus huruf kapital & minimal 4 digit, contoh: BEM1");
      return;
    }
    if (!form.jenis || !form.posisi || !form.poin) {
      alert("Semua field wajib diisi!");
      return;
    }
    onSave(form);
    setForm({ kode: "", jenis: "", posisi: "", poin: 0 });
    onClose();
  };

  if (!isOpen) return null;

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black bg-opacity-50"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-sm mx-3 bg-white rounded-lg shadow-lg overflow-auto max-h-[85vh] z-50 animate-fadeIn">
        {/* Header */}
        <div className="flex justify-between items-center px-4 py-2 border-b">
          <h2 className="text-sm font-medium text-gray-800 flex items-center">
            <i className="fas fa-plus-circle mr-1.5 text-blue-600 text-xs"></i>
            Tambah Master Poin
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition text-xs"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="px-4 py-3 space-y-3">
          {["kode", "jenis", "posisi", "poin"].map((field, idx) => {
            const label =
              field === "kode"
                ? "Kode"
                : field === "jenis"
                ? "Jenis Kegiatan"
                : field === "posisi"
                ? "Posisi / Peran"
                : "Poin";
            const type = field === "poin" ? "number" : "text";
            return (
              <div key={idx}>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  {label}
                </label>
                <input
                  type={type}
                  name={field}
                  value={form[field]}
                  onChange={handleChange}
                  placeholder={`Masukkan ${label.toLowerCase()}`}
                  min={field === "poin" ? 0 : undefined}
                  className="w-full px-2.5 py-1.5 border border-gray-300 rounded-md shadow-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none text-xs bg-white text-black uppercase"
                  required
                />
              </div>
            );
          })}

          {/* Tombol */}
          <div className="flex justify-end gap-1.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition text-xs"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-3 py-1.5 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition shadow-sm text-xs"
            >
              Simpan
            </button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
}
